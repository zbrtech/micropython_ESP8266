# all tests need print to work! make sure it does work

print(1)
print('abc')
