i = 123456789012345678901234567890
print(i >> 1)
print(i >> 1000)

# result needs rounding up
print(-(1<<70) >> 80)
