# tests that .../Ellipsis exists

print(...)
print(Ellipsis)

print(... == Ellipsis)
