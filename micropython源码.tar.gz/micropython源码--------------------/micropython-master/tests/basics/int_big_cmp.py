# test bignum comparisons

i = 1 << 65

print(i == 0)
print(i != 0)
print(i < 0)
print(i > 0)
print(i <= 0)
print(i >= 0)
