import import1b
print(import1b.var)
