# check REPL allows to continue input
1 \
+ 2
'"'
"'"
'\''
"\""
'\'('
"\"("
print("\"(")
print('\'(')
print("\'(")
print('\"(')
'abc'
"abc"
'''abc
def'''
"""ABC
DEF"""
print(
1 + 2)
l = [1,
2]
print(l)
d = {1:'one',
2:'two'}
print(d[2])
def f(x):
print(x)

f(3)
if1=1
if1 = 2
print(if1)
