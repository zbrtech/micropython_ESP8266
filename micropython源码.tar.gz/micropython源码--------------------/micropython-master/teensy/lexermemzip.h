mp_lexer_t *mp_lexer_new_from_memzip_file(const char *filename);

