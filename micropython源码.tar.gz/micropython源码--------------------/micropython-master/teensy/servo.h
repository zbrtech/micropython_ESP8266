void servo_init(void);

extern const mp_obj_type_t pyb_servo_type;

MP_DECLARE_CONST_FUN_OBJ(pyb_servo_set_obj);
MP_DECLARE_CONST_FUN_OBJ(pyb_pwm_set_obj);

