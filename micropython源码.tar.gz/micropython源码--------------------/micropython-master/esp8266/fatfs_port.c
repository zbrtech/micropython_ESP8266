#include "lib/fatfs/ff.h"
#include "lib/fatfs/diskio.h"

DWORD get_fattime(void) {
    return 0;
}
